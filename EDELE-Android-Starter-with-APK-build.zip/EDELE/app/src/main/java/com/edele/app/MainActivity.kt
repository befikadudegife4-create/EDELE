package com.edele.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Cream = Color(0xFFF7F0E3)
private val Ink = Color(0xFF211B17)
private val Gold = Color(0xFFDCA83A)
private val Rust = Color(0xFF913E2D)
private val Muted = Color(0xFF8E8375)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EdeleApp() }
    }
}

data class Product(val name: String, val category: String, val price: String, val emoji: String, val isAuction: Boolean = false)

@Composable
fun EdeleApp() {
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedProduct by remember { mutableStateOf<Product?>(null) }
    var paymentMethod by remember { mutableStateOf("Telebirr") }
    val products = listOf(
        Product("iPhone 17 Pro Max", "Phones", "Ask seller", "📱"),
        Product("HP Laptop Core i5 11th Gen", "Computers", "50,000 ETB", "💻", true),
        Product("Wireless Headphones", "Accessories", "3,500 ETB", "🎧"),
        Product("PlayStation 5", "Gaming", "Ask seller", "🎮", true)
    )

    MaterialTheme(colorScheme = lightColorScheme(primary = Gold, background = Cream, surface = Color(0xFFFFFCF6))) {
        Scaffold(
            containerColor = Cream,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFFFFFCF6), contentColor = Ink) {
                    NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0; selectedProduct = null }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                    NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1; selectedProduct = null }, icon = { Icon(Icons.Default.GridView, null) }, label = { Text("Shop") })
                    NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2; selectedProduct = null }, icon = { Icon(Icons.Default.ConfirmationNumber, null) }, label = { Text("Auctions") })
                    NavigationBarItem(selected = selectedTab == 3, onClick = { selectedTab = 3; selectedProduct = null }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("Profile") })
                }
            }
        ) { padding ->
            if (selectedProduct != null) {
                ProductDetails(product = selectedProduct!!, paymentMethod = paymentMethod, onPaymentChange = { paymentMethod = it }, onBack = { selectedProduct = null }, modifier = Modifier.padding(padding))
            } else when (selectedTab) {
                0 -> HomeScreen(products, onOpen = { selectedProduct = it }, modifier = Modifier.padding(padding))
                1 -> ShopScreen(products, onOpen = { selectedProduct = it }, modifier = Modifier.padding(padding))
                2 -> AuctionScreen(products.filter { it.isAuction }, onOpen = { selectedProduct = it }, modifier = Modifier.padding(padding))
                else -> ProfileScreen(paymentMethod, onPaymentChange = { paymentMethod = it }, modifier = Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun Header() {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Surface(shape = RoundedCornerShape(30.dp), color = Color(0xFFFFFCF6), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE4D9C7))) {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Language, null, tint = Ink); Spacer(Modifier.width(7.dp)); Text("AM / EN", color = Ink, fontSize = 12.sp) }
        }
        Text("EDELE", color = Ink, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
        Surface(shape = RoundedCornerShape(50), color = Gold) { Text("E", Modifier.padding(horizontal = 14.dp, vertical = 7.dp), color = Ink, fontWeight = FontWeight.Black, fontSize = 20.sp) }
    }
}

@Composable
fun HomeScreen(products: List<Product>, onOpen: (Product) -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize()) {
        item { Header() }
        item {
            Column(Modifier.padding(horizontal = 18.dp).fillMaxWidth().background(Ink, RoundedCornerShape(30.dp)).padding(24.dp)) {
                Text("WELCOME TO EDELE", color = Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(Modifier.height(14.dp))
                Text("Shop smart.\nBid for more.", color = Color.White, fontSize = 32.sp, lineHeight = 38.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(12.dp))
                Text("Discover products and join live auctions.", color = Color(0xFFD4C8B8), fontSize = 14.sp)
                Spacer(Modifier.height(20.dp))
                Button(onClick = { onOpen(products[0]) }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink), shape = RoundedCornerShape(16.dp)) { Text("Explore products  →", fontWeight = FontWeight.Bold) }
            }
        }
        item { SectionTitle("Featured products", "Explore") }
        items(products.take(3)) { ProductCard(it, onOpen) }
        item { Spacer(Modifier.height(12.dp)) }
    }
}

@Composable
fun ShopScreen(products: List<Product>, onOpen: (Product) -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize()) {
        item { Header() }
        item { Text("Find your next favorite", Modifier.padding(horizontal = 20.dp, vertical = 8.dp), fontSize = 27.sp, lineHeight = 32.sp, fontWeight = FontWeight.ExtraBold, color = Ink) }
        item { OutlinedTextField(value = "", onValueChange = {}, enabled = false, placeholder = { Text("Search products") }, leadingIcon = { Icon(Icons.Default.Search, null) }, modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp), shape = RoundedCornerShape(20.dp)) }
        item { Spacer(Modifier.height(14.dp)) }
        items(products) { ProductCard(it, onOpen) }
    }
}

@Composable
fun AuctionScreen(products: List<Product>, onOpen: (Product) -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize()) {
        item { Header() }
        item { Text("Live auctions", Modifier.padding(horizontal = 20.dp, vertical = 8.dp), fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, color = Ink) }
        item { Text("Choose an item to view auction details.", Modifier.padding(horizontal = 20.dp), color = Muted) }
        items(products) { ProductCard(it, onOpen) }
    }
}

@Composable
fun SectionTitle(title: String, action: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 20.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text(action, fontSize = 13.sp, color = Rust, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ProductCard(product: Product, onOpen: (Product) -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 7.dp).clickable { onOpen(product) }, shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFCF6)), elevation = CardDefaults.cardElevation(1.dp)) {
        Column {
            Box(Modifier.fillMaxWidth().height(150.dp).background(Color(0xFFECE1D0)), contentAlignment = Alignment.Center) {
                Text(product.emoji, fontSize = 70.sp)
                if (product.isAuction) Surface(Modifier.align(Alignment.TopStart).padding(12.dp), shape = RoundedCornerShape(20.dp), color = Gold) { Text("AUCTION", Modifier.padding(horizontal = 12.dp, vertical = 6.dp), fontSize = 10.sp, color = Ink, fontWeight = FontWeight.Bold) }
            }
            Column(Modifier.padding(16.dp)) {
                Text(product.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
                Spacer(Modifier.height(5.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(product.category, color = Muted, fontSize = 12.sp)
                    Text(product.price, color = Ink, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ProductDetails(product: Product, paymentMethod: String, onPaymentChange: (String) -> Unit, onBack: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("← Back", Modifier.clickable { onBack() }, color = Rust, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        Box(Modifier.fillMaxWidth().height(210.dp).background(Color(0xFFECE1D0), RoundedCornerShape(28.dp)), contentAlignment = Alignment.Center) { Text(product.emoji, fontSize = 95.sp) }
        Spacer(Modifier.height(20.dp))
        Text(product.name, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        Text(product.category, color = Muted)
        Spacer(Modifier.height(12.dp))
        Text(if (product.isAuction) "Auction item" else "Available product", color = Rust, fontWeight = FontWeight.Bold)
        Text(product.price, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(24.dp))
        Text("Payment method", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
        listOf("Telebirr", "CBE Birr").forEach { method ->
            Row(Modifier.fillMaxWidth().padding(top = 10.dp).background(if (paymentMethod == method) Color(0xFFF0DDAA) else Color(0xFFFFFCF6), RoundedCornerShape(16.dp)).clickable { onPaymentChange(method) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(if (method == "Telebirr") Icons.Default.PhoneAndroid else Icons.Default.AccountBalance, null, tint = Ink)
                Spacer(Modifier.width(12.dp)); Text(method, Modifier.weight(1f), color = Ink, fontWeight = FontWeight.SemiBold)
                RadioButton(selected = paymentMethod == method, onClick = { onPaymentChange(method) })
            }
        }
        Spacer(Modifier.height(20.dp))
        Button(onClick = {}, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink), shape = RoundedCornerShape(16.dp)) { Text(if (product.isAuction) "Join auction" else "Continue", fontWeight = FontWeight.Bold) }
        Text("Demo only: payment processing is not connected yet.", Modifier.padding(top = 12.dp), color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun ProfileScreen(paymentMethod: String, onPaymentChange: (String) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Header()
        Text("Your profile", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        Text("Manage your EDELE account and payments.", color = Muted)
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth().background(Ink, RoundedCornerShape(24.dp)).padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AccountCircle, null, tint = Gold, modifier = Modifier.size(48.dp))
            Spacer(Modifier.width(14.dp)); Column { Text("Welcome to EDELE", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp); Text("Sign-in and account setup coming next", color = Color(0xFFD4C8B8), fontSize = 12.sp) }
        }
        Spacer(Modifier.height(24.dp))
        Text("Preferred payment", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
        listOf("Telebirr", "CBE Birr").forEach { method ->
            Row(Modifier.fillMaxWidth().padding(top = 10.dp).background(Color(0xFFFFFCF6), RoundedCornerShape(16.dp)).clickable { onPaymentChange(method) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(if (method == "Telebirr") Icons.Default.PhoneAndroid else Icons.Default.AccountBalance, null, tint = Rust)
                Spacer(Modifier.width(12.dp)); Text(method, Modifier.weight(1f), color = Ink); RadioButton(selected = paymentMethod == method, onClick = { onPaymentChange(method) })
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("Language: Amharic / English", color = Muted)
        Text("Version 0.1.0 • Prototype", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 20.dp))
    }
}
