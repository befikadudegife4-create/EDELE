# EDELE Android starter app

A native Android Jetpack Compose starter for EDELE, a shopping + auction app concept inspired by the supplied design references.

## Included
- Home, Shop, Auctions, and Profile tabs
- Product cards and detail view
- Telebirr and CBE Birr payment-method selection UI
- Cream, black, and gold visual theme
- GitHub Actions workflow (`.github/workflows/build-apk.yml`) to build a debug APK in the cloud

## Important limitations
This is an early UI prototype. It does **not** yet process real payments, authenticate users, store products online, or run live auctions. Those require a backend and official merchant/API integration with Telebirr and CBE Birr. Never put payment secrets in the Android app.

## Build APK
### With Android Studio
Open this folder in Android Studio, let Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

### With GitHub Actions
1. Create a GitHub repository and upload the contents of this folder.
2. Open the repository's **Actions** tab and run **Build EDELE APK** (or push to `main`).
3. Open the completed workflow run and download the `EDELE-debug-apk` artifact.
4. Extract the downloaded artifact to get `app-debug.apk`.

A debug APK is for testing, not Play Store release. A signed release build and backend/payment integrations are separate steps.
